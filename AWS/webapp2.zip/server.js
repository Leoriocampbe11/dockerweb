const express = require('express');
const path = require('path');
const app = express();

// Servir archivos estáticos desde el directorio actual
app.use(express.static(path.join(__dirname)));

// Manejar rutas desconocidas redirigiendo a index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Inicia el servidor en el puerto 8080
const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en el puerto ${PORT}`);
});
